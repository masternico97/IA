# import the library
from appJar import gui
from PIL import Image, ImageTk
from login import Login
from socketConexion import SocketConexion
import numpy as np
from conexionUam import ConexionUAM
import cv2
import socket
import threading



class VideoClient(object):

    def __init__(self, window_size):
        
        # Creamos una variable que contenga el GUI principal
        self.app = gui("Redes2 - P2P", window_size)
        self.app.setBg("#3399ff")
        self.app.setGuiPadding(10,10)

        # Preparación del interfaz
        self.app.addLabel("title", "Cliente Multimedia P2P - Redes2 ")
        self.app.addImage("video", "imgs/webcam.gif")

        # Registramos la función de captura de video
        self.cap = cv2.VideoCapture(0)
        self.app.setPollTime(20)
        self.app.registerEvent(self.capturaVideo)

        # Añadir los botones
        self.app.addButtons(["Conectar", "Listar", "Salir"], self.buttonsCallback)

        # Evento para terminar de esperar llamdas
        self.e = threading.Event()

        # Ventana para listar usuarios
        self.app.startSubWindow("Redes2 - Usuarios", modal=True)
        self.app.setBg("#3399ff")
        self.app.addLabel("lstUsers", "Lista de usuarios registrados")
        self.app.addListBox("list", [])
        self.app.stopSubWindow()

        self.sc = None
        hilo = threading.Thread(target=self.aceptarNuevaPeticion)
        hilo.start()

    ##################################
    # FUNCIÓN: def start(self):
    # ARGS_IN: 
    # DESCRIPCIÓN: Inicia la interfaz principal de la aplicacion
    # ARGS_OUT: 
    #################################
    def start(self):
        self.app.go()

    ##################################
    # FUNCIÓN: def capturaVideo(self):
    # ARGS_IN: 
    # DESCRIPCIÓN: captura el frame a mostrar en cada momento 
    # en la imagen de la interfaz inicial
    # ARGS_OUT: 
    #################################
    def capturaVideo(self):
        
        # Capturamos un frame de la cámara o del vídeo
        ret, frame = self.cap.read()
        # Redefinimos el tamaño de la imagen
        frame = cv2.resize(frame, (640,480))
        # Pasamos el frame a color RGB 
        cv2_im = cv2.cvtColor(frame,cv2.COLOR_BGR2RGB)
        # Obtenemos la imagen del frame
        img_tk = ImageTk.PhotoImage(Image.fromarray(cv2_im))            

        # Lo mostramos en el GUI
        self.app.setImageData("video", img_tk, fmt = 'PhotoImage')

    ##################################
    # FUNCIÓN: def setImageResolution(self, resolution):
    # ARGS_IN: resolution - string con la resolucion a la que queremos cambiar
    # DESCRIPCIÓN: establece la resolución de la imagen capturada
    # ARGS_OUT: 
    #################################
    def setImageResolution(self, resolution):       
        
        if resolution == "LOW":
            self.cap.set(cv2.CAP_PROP_FRAME_WIDTH, 160) 
            self.cap.set(cv2.CAP_PROP_FRAME_HEIGHT, 120) 
        elif resolution == "MEDIUM":
            self.cap.set(cv2.CAP_PROP_FRAME_WIDTH, 320) 
            self.cap.set(cv2.CAP_PROP_FRAME_HEIGHT, 240) 
        elif resolution == "HIGH":
            self.cap.set(cv2.CAP_PROP_FRAME_WIDTH, 640) 
            self.cap.set(cv2.CAP_PROP_FRAME_HEIGHT, 480) 
                
    ##################################
    # FUNCIÓN: def buttonsCallback(self, button):
    # ARGS_IN: button - string con el nombre del boton pulsado
    # DESCRIPCIÓN: gestiona los callbacks de los botones
    # ARGS_OUT: 
    #################################
    def buttonsCallback(self, button):

        if button == "Salir":
            # Salimos de la aplicación
            self.e.set()
            ip = self.sc.getMyIp()
            s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            s.connect((ip, 8080))
            s.close()
            self.app.stop()
        elif button == "Conectar":
            # Entrada del nick del usuario a conectar  
            nick = self.app.textBox("Conexión", 
                "Introduce el nick del usuario a buscar")
            try:
                # Obtenemos los datos del nick  
                info = self.obtenerDatos(nick)
                ip = info[3]
                port = int(info[4])
                # Realizamos una peticion de llamada
                self.realizarNuevaPeticion(ip, port, nick)
            except TypeError:
                pass
            
        elif button == "Listar":
            self.listarUsuariosServidor()
        else:
            pass

    def listarUsuariosServidor(self):
        c = ConexionUAM()
        c.conectar()
        c.enviar(('LIST_USERS').encode())
        data = c.recibir(15000)
        token = data.decode().split(" ")
        c.enviar(('QUIT').encode())
        c.cerrar()
        if token[0] == 'NOK':
            self.app.warningBox("Error", "Los usuario no han podido recuperarse", parent=None)
            return
        lst = []
        for users in data[14:].decode().split("#"):
            lst.append(users.split(" ")[0])

        self.app.clearListBox("list", callFunction=False)
        self.app.addListItems("list", lst)
        self.app.showSubWindow("Redes2 - Usuarios")
            

    def obtenerDatos(self, nick):
        c = ConexionUAM()
        c.conectar()
        c.enviar(('QUERY '+nick+'').encode())
        data = c.recibir(1024)
        c.enviar(('QUIT').encode())
        c.cerrar()
        tokens = data.decode().split(" ")
        if tokens[0] == 'NOK':
            self.app.warningBox("Error", "El usuario no existe", parent=None)
        else: 
            return tokens


    def aceptarNuevaPeticion(self):

        self.sc = SocketConexion(self.app, self.cap)
        st = self.sc.getSocket()        
        # Nos quedamos a la espera de nuevas peticiones
        while not self.e.isSet():
            # Recibimos peticion
            s, addr = st.accept()
            if(addr[0] == self.sc.getMyIp()):
                pass
                
            else:
                if self.sc.getPeerTCP() == None or self.sc.getEstado() == 0:
                    r = self.app.questionBox("Redes2 - Llamada entrante", "¿Aceptar llamada?", parent=None)
                    if r == "yes":
                        self.sc.setPeerTCP(s)
                        self.sc.setAddres(addr)
                        self.sc.setEstado(1)
                        data = s.recv(1024).decode('utf-8')
                        nick = data.split(" ")[1]
                        portDest = data.split(" ")[2]
                        s.send(('CALL_ACCEPT '+nick+' 8090').encode())   
                        hilo = threading.Thread(target=self.sc.gestorLlamada, args=(portDest,))
                        hilo.start()
                    else:
                        data = s.recv(1024).decode('utf-8')
                        nick = data.split(" ")[1]
                        s.send(('CALL_DENIED'+nick+'').encode())
                    
                elif self.sc.getEstado() == 1:
                    s.recv(1024)
                    s.send(('CALL_BUSY').encode())
                else:
                    pass


    def realizarNuevaPeticion(self, ip, port, nick):

        s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        s.connect((ip, port))
        s.send(('CALLING '+nick+' 8090').encode())
        data = s.recv(1024).decode('utf-8')
        response = data.split(" ")
        if response[0] == 'CALL_ACCEPT':
            self.sc.setPeerTCP(s)
            self.sc.setAddres((ip, port))
            self.sc.setEstado(1)
            #Hilo para preparar TCP e UDP
            hilo = threading.Thread(target=self.sc.gestorLlamada, args=(response[2],))
            hilo.start()
        elif response[0] == 'CALL_DENIED':
             self.app.warningBox("Error", "El usuario denego la llamada", parent=None)
             pass
        elif response[0] == 'CALL_BUSY':
            self.app.warningBox("Error", "El usuario se encuentra en una llamada", parent=None)
            pass
        else:
            pass 


        

if __name__ == '__main__':

    lg = Login()
    lg.loginWindow("300x200")
    lg.start()
    if lg.getVal() == 0:
        vc = VideoClient("640x520")
        vc.start()