# import the library
from appJar import gui
import numpy as np
from conexionUam import ConexionUAM

class Login(object):

    def __init__(self):

        self.uam = ConexionUAM()
        self.val = 1

    def loginWindow(self, window_size):

        # Creamos una variable que contenga el GUI principal
        self.app = gui("Redes2 - P2P", window_size)
        self.app.setGuiPadding(10,10)

        # Preparación del interfaz
        self.app.addLabel("title", "Login - Redes2")

        # Entrada del nick del usuario a conectar 
        self.app.addLabelEntry("Nick")
        # Entrada de la contrasenia del usuario a conectar 
        self.app.addLabelSecretEntry("Password")

        # Añadir los botones
        self.app.addButtons(["Aceptar", "Salir"], self.press)


    # Función que gestiona los callbacks de los botones
    def press(self, button):

        if button == "Salir":
            # Salimos de la aplicación
            self.app.stop()
        elif button == "Aceptar":
  
            nick = self.app.getEntry("Nick")
            pwd = self.app.getEntry("Password")
            self.uam.conectar()
            ipS = self.uam.getIp()
            self.uam.enviar(('REGISTER '+nick+' '+ipS+' 8080 '+pwd+' V1').encode()) 
            data = self.uam.recibir(1024)
            self.uam.enviar(('QUIT').encode())
            self.uam.cerrar()
            if data.decode() == 'NOK WRONG_PASS':
                self.app.warningBox("Error", "Contrasenia incorrecta", parent=None)
            else:
                self.val = 0
                self.app.stop()  

    def getVal(self):
        return self.val           

    def start(self):
        self.app.go()
