import socket
import cv2
import numpy as np
from PIL import Image, ImageTk
import threading
import time

n_sem = 1
semaforoUDP = threading.Semaphore(n_sem)
#acquire() - Decrementa
#release() - Aumenta

class SocketConexion(object):
    
    def __init__(self, app, cap):

        #Obtenemos la IP del ordenador
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        s.connect(("8.8.8.8", 80))
        self.ipS = s.getsockname()[0]
        s.close()
        
        # Iniciamos la escucha
        self.socketTCP = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        self.socketTCP.bind((self.ipS, 8080))
        self.socketTCP.listen(5)

        # 0 - No hay conversacion / 1 - Existe conversacion
        self.estado = 0

        #0 - Llamada continua / 1 - Llamada pausada
        self.pausa = 0
        self.pausaHost = 0

        # Socket al peer de la conversacion. Aqui recibimos y enviamos datos TCP.
        self.peerTCP = None

        #Abrimos conexion UDP
        self.peerUDP = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        self.peerUDP.bind((self.ipS, 8090))

        #Control del GUI
        self.app = app
        self.cap = cap

        # Ventana de comunicacion
        self.app.startSubWindow("Redes2 - Videollamada", modal=True)
        self.app.setBg("#3399ff")
        self.app.addImage("llamada", "imgs/webcam.gif")
        self.app.setPollTime(20)
        self.app.addButtons(["Pausar", "Reanudar", "Colgar"], self.botonesControl)
        self.app.stopSubWindow()
        
        # Evento para establecer el final de la llamada
        self.e = threading.Event()

        # Tupla con ip y puerto(TCP) del otro host
        self.addr = None

    def getSocket(self):
        return self.socketTCP

    def getEstado(self):
        return self.estado

    def setEstado(self, val):
        self.estado = val
        pass

    def getAddres(self):
        return self.addr

    def getMyIp(self):
        return self.ipS

    def setAddres(self, val):
        self.addr = val
        pass

    def getPeerTCP(self):
        return self.peerTCP

    def setPeerTCP(self, s):
        self.peerTCP = s
        pass

    def gestorLlamada(self, pDest):

        #Lanzamos hilos TCP y UDP
        self.e.clear()
        rcvTCP = threading.Thread(target=self.recibirTCP)
        sndUDP = threading.Thread(target=self.enviarUDP, args=(pDest,))
        rcvUDP = threading.Thread(target=self.recibirUDP)
        rcvTCP.start()
        sndUDP.start()
        rcvUDP.start()
        self.ventanaLlamada()

        
    def recibirTCP(self):

        self.peerTCP.setblocking(0)

        while not self.e.isSet():
            try:
                verb = self.peerTCP.recv(1024).decode('utf-8').split(" ")[0]
                if verb == 'CALL_HOLD':
                    self.pausaHost = 1
                    self.app.infoBox("Pausa", "Llamada pausada por el extremo", parent=None)
                elif verb == 'CALL_RESUME':
                    self.pausaHost = 0
                    self.app.infoBox("Reanudar", "Llamada reanudada por el extremo", parent=None)
                elif verb == 'CALL_END':
                    self.e.set()
                    time.sleep(1)
                    self.setEstado(0)
                    self.setAddres(None)
                    self.peerTCP.close()
                    self.setPeerTCP(None)
                    self.pausa = 0
                    self.pausaHost = 0
                    self.app.hideSubWindow("Redes2 - Videollamada")
                else:
                    pass
            except socket.timeout:
                pass
            except socket.error:
                pass
            


    def enviarTCP(self, message):

        self.peerTCP.send(message.encode())

    def enviarUDP(self, pDst):

        while not self.e.isSet():
            
            if self.pausa == 0 and self.pausaHost == 0:
                semaforoUDP.acquire()
                ret, frame = self.cap.read()
                last_frame = frame
                semaforoUDP.release()
            else:
                frame = last_frame

            # Compresión JPG al 50% de resolución (se puede variar)
            encode_param = [cv2.IMWRITE_JPEG_QUALITY,50]        
            result, encimg = cv2.imencode('.jpg', frame, encode_param)
            if result == False: 
                print('Error al codificar imagen')
            encimg = encimg.tobytes()        
            self.peerUDP.sendto(encimg, (self.addr[0], int(pDst)))
            

    def recibirUDP(self):

        while not self.e.isSet():

            encimg, addr = self.peerUDP.recvfrom(80120)  
            # Descompresión de los datos, una vez recibidos
            decimg = cv2.imdecode(np.frombuffer(encimg,np.uint8), 1)
            semaforoUDP.acquire()
            ret, frame = self.cap.read()
            semaforoUDP.release()

            #Redirecciona el tamaño de las imagenes
            frame_base = cv2.resize(decimg, (640,480))
            frame_peque = cv2.resize(frame, (160,120))
            frame_compuesto = frame_base
            frame_compuesto[0:frame_peque.shape[0], 0:frame_peque.shape[1]] = frame_peque
            # Conversión de formato para su uso en el GUI
            cv2_im = cv2.cvtColor(frame_compuesto, cv2.COLOR_BGR2RGB)
            img_tk = ImageTk.PhotoImage(Image.fromarray(cv2_im))
            # Lo mostramos en el GUI
            self.app.setImageData("llamada", img_tk, fmt = 'PhotoImage')
        
        
    def ventanaLlamada(self):

        self.app.showSubWindow("Redes2 - Videollamada")

    # Función que gestiona los callbacks de los botones
    def botonesControl(self, button):

        if button == "Pausar":
            # Pausamos la comunicacion
            self.app.infoBox("Pausa", "Llamada pausada", parent=None)
            self.enviarTCP('CALL_HOLD nick')
            self.pausa = 1
        elif button == "Reanudar":
            # Reanudamos la comunicacion
            self.app.infoBox("Pausa", "Llamada reanudada", parent=None)
            self.enviarTCP('CALL_RESUME nick')
            self.pausa = 0
        elif button == "Colgar":
            self.enviarTCP('CALL_END nick')
            self.e.set()
            time.sleep(1)
            self.setEstado(0)
            self.setAddres(None)
            self.peerTCP.close()
            self.setPeerTCP(None)
            self.pausa = 0
            self.pausaHost = 0
            self.app.hideSubWindow("Redes2 - Videollamada")
            
        else:
            pass











        