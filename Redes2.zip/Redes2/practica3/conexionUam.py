import socket

class ConexionUAM(object):

    def __init__(self):

        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        s.connect(("8.8.8.8", 80))
        self.ipS = s.getsockname()[0]
        s.close()

    def conectar(self):

        self.socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        self.socket.connect(('vega.ii.uam.es', 8000))

    def enviar(self, mensaje):

        self.socket.send(mensaje)

    def recibir(self, nBytes):

        data = self.socket.recv(nBytes)
        return data

    def getIp(self):
        return self.ipS

    def cerrar(self):

        self.socket.close()
