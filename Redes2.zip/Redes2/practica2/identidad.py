#############################################################
# FILE: identidad.py
#
#
# AUTHOR:  Jorge Gutierrez Diaz
#           Patricia Losana Ferrer
#
# DESCRIPTION: la clase Identidad gestiona las identidades (crear, 
#           exportar, buscar y borrar usuarios) y datos de 
#           identificacion
#
#############################################################

import argparse, requests
import json
from excepciones import *
from Crypto.PublicKey import RSA

#Token de autenticacion 
#La descripcion del API especifica que la cabecera debe ser
# Autorization: Bearer [Token] (por eso incluimos aqui el bearer)
TOKEN = "Bearer fAB65b7310c2aE9F"


class Identidad:

    #Constructor de la clase Identidad
    def __init__(self):
        pass


    ##########################################################
    # METODO: registrarUsuario(self, nombre, correo)
    # ARGS_IN: self: objeto Identidad
    #          nombre: nombre del usuario
    #          correo: correo del usuario
    #
    # DESCRIPCION: Crea una nueva identidad en SecureBox para el nombre y 
    #              correo dados (genera un par de claves publca y privada) 
    #               al utilizar '--create_id [nombre] [correo]''
    #
    # ARGS_OUT: -
    #
    ##########################################################

    def registrarUsuario(self, nombre, correo):

        #Generacion de la clave privada
        key = RSA.generate(2048)
        
        #PEM es el formato que necesita RSA para poder cifrar
        encrypted_key = key.exportKey('PEM')
        
        #Almacenamiento de la clave privada en el fichero miKey.bin
        f = open('miKey.bin', 'wb')
        f.write(encrypted_key)
        f.close()

        #Obtenencion de la clave publica
        public_Key = key.publickey()
        #print(public_Key.exportKey('PEM'))


        print("Generando par de claves RSA de 2048 bits...OK")

        #Peticion de registro al servidor SecureBox (users/register)
        url = 'https://vega.ii.uam.es:8080/api/users/register'
        
        #Datos del usuario asociados al registro
        datos = {
            'nombre': nombre,
            'email': correo,
            'publicKey': public_Key.exportKey('PEM').decode('utf-8')
        }

        #Cabecera HTTP a incluir
        cabeceras = {
            'Authorization': TOKEN
        }
        
        #Envio de la peticion al servidor (metodo POST)
        r = requests.post(url, json=datos, headers=cabeceras)
        
        #Comprobacion de si la peticion HTTP fue correcta (codigo de estatus 200)
        if r.status_code == 200:
            print("Identidad con ID#336869 creada correctamente")
        
        #Si la peticion es erronea, comprobacion del error
        else:
            #Parseo la respuesta de la peticion por estar en JSON
            data = json.loads(r.content.decode('utf-8'))
            self.tratarError(data)


    ##########################################################
    # METODO: buscarUsuario(self, nombre)
    # ARGS_IN: self: objeto Identidad
    #          nombre: nombre del usuario
    #
    # DESCRIPCION: Busca en SecureBox un usuario a partir de su nombre o su
    #               correo y devuelve su ID '--search_id [nombre]'
    #   
    # ARGS_OUT: todos los usuarios que tengan un campo coincidente
    #   con el nombre introducido (indiferentemende de nombre o correo)
    #
    ##########################################################
    
    def buscarUsuario(self, nombre):

        #Peticion de busqueda al servidor SecureBox (users/search)
        url = 'https://vega.ii.uam.es:8080/api/users/search'
        datos = {
            'data_search': nombre
        }
        cabeceras = {
            'Authorization': TOKEN,
            'Content-type': 'application/json'
        }
        
        #Envio de la peticion
        r = requests.post(url, data=json.dumps(datos), headers=cabeceras)
        
        #Parseo de la respuesta de la peticion por estar en JSON
        data = json.loads(r.content.decode('utf-8'))
        
        #Comprobacion de que la peticion HTTP fue correcta
        if r.status_code == 200:
            print("Searching for identity...OK")
            
            #Impresion de los usuarios encontrados
            for i in data:
                print("Identity with ID#", i['userID'], "found")
                print("Name: ", i['nombre'],"")
                print("Email: ", i['email'],"\n")
        
        #Si la peticion fue erronea, comprobacion del error
        else:
            self.tratarError(data)

    ##########################################################
    # METODO: conseguirClavePublica(self, idUser)
    # ARGS_IN: self: objeto Identidad
    #          idUser: id del usuario
    #
    # DESCRIPCION: Dado un ID de usuario consulta en SecureBox y devuelve
    #   su clave publica
    #
    # ARGS_OUT: data['publicKey']: la clave publica
    #
    ##########################################################
    def conseguirClavePublica(self, idUser):

        #Peticion al servidor (users/getPublicKey).
        url = 'https://vega.ii.uam.es:8080/api/users/getPublicKey'
        datos = {
            'userID': idUser
        }
        cabeceras = {
            'Authorization': TOKEN,
            'Content-type': 'application/json'
        }

        #Envio de la peticion
        r = requests.post(url, data=json.dumps(datos), headers=cabeceras)
        
        #Parseo de la respuesta de la peticion por estar en JSON
        data = json.loads(r.content.decode('utf-8'))
        
        #Comprobacion de que la peticion HTTP fue correcta
        if r.status_code == 200:
            #Devolucion de la clave publica del usuario buscado
            return data['publicKey']
        #Si la peticion fue erronea, comprobacion del error
        else:
            self.tratarError(data)
        

    ##########################################################
    # METODO: eliminarUsuario(self, idUser) 
    # ARGS_IN: self: objeto Identidad
    #          idUser: id del usuario
    #
    # DESCRIPCION: Elimina un usuario a partir de su id
    #               '--delete_id [id]'
    #
    # ARGS_OUT: -
    #   
    ##########################################################
    
    def eliminarUsuario(self, idUser):

        #Peticion al servidor (users/delete)
        url = 'https://vega.ii.uam.es:8080/api/users/delete'
        datos = {
            'userID': idUser
        }
        cabeceras = {
            'Authorization': TOKEN,
            'Content-type': 'application/json'
        }
        
        #Envio de la peticion
        r = requests.post(url, data=json.dumps(datos), headers=cabeceras)
        
        #Comprobacion del codigo devuelto por HTTP
        if r.status_code == 200:
            print("Requesting removal of identity #336869...OK")
            print("Identity with ID#336869 sucessfully deleted")
        
        #Si la peticion fue erronea, comprobacion del error
        else:
            #Parseo de la respuesta por estar en JSON
            data = json.loads(r.content.decode('utf-8'))
            self.tratarError(data)

    ##########################################################
    # METODO: listarFicheros(self)
    # ARGS_IN: self: objeto Identidad
    #
    # DESCRIPCION: Lista todos los ficheros pertenecientes a un usuario
    # ARGS_OUT: -
    #   
    ##########################################################
    
    def listarFicheros(self):

        #Peticion al servidor(/files/list)
        url = 'https://vega.ii.uam.es:8080/api/files/list'
        cabeceras = {
            'Authorization': TOKEN,
            'Content-type': 'application/json'
        }
        
        #Envio de la peticion
        r = requests.post(url, headers=cabeceras)
        
        #Parseo de la respuesta de la peticion por estar en JSON
        data = json.loads(r.content.decode('utf-8'))

        #Comprobacion del codigo devuelto por HTTP
        if r.status_code == 200:
            print("Searching for files...OK\n")
            
            #Impresion de las listas encontradas
            for i in data['files_list']:
                print("File: ", i['fileName'], "")
                print("FileID: ", i['fileID'],"\n")
            print("Total files: ", data['num_files'])
        
        #Si la peticion fue erronea, comprobamos el error
        else:
            self.tratarError(data)

    ##########################################################
    # METODO: eliminarFichero: 
    # ARGS_IN: self: objeto Identidad
    #          fileID: id del fichero
    #
    # DESCRIPCION: Borra un fichero del sistema
    #
    # ARGS_OUT: -
    #   
    ##########################################################
    
    def eliminarFichero(self, fileID):

        #Peticion al servidor (/files/delete)
        url = 'https://vega.ii.uam.es:8080/api/files/delete'
        cabeceras = {
            'Authorization': TOKEN,
            'Content-type': 'application/json'
        }
        datos = {
            'file_id': fileID
        }
        #Envio de la peticion
        r = requests.post(url, json=datos, headers=cabeceras)
        
        #Parseo de la respuesta de la peticion por estar en JSON
        data = json.loads(r.content.decode('utf-8'))

        #Comprobacion del codigo devuelto por HTTP
        if r.status_code == 200:
            print("Fichero con ID",fileID,"eliminado")
        
        #Si la peticion fue erronea, comprobacion del error
        else:
            self.tratarError(data)


    ##########################################################
    # METODO: tratarError(self, data)
    # ARGS_IN: self: objeto Cifrar
    #          data: error
    #
    # DESCRIPCION: Lanza la excepcion del error correspondiente 
    #   y crea un objeto del tipo Error que corresponda 
    #   (excepciones.py)
    #
    # ARGS_OUT: -
    #
    ##########################################################
    
    def tratarError(self, data):

        #Token de usuario incorrecto
        if data['error_code'] == 'TOK1':
            raise ErrorTOK1(data['description'])
        
        #Token de usuario caducado, se debe solicitar uno nuevo
        elif data['error_code'] == 'TOK2':
            raise ErrorTOK2(data['description'])
        
        #Falta cabecera de autenticacion
        elif data['error_code'] == 'TOK3':
            raise ErrorTOK3(data['description'])

        #Se supera el tamanyo maximo de fichero
        elif data['error_code'] == 'FILE1':
            raise ErrorFILE1(data['description'])
        
        #El ID del fichero no es correcto
        elif data['error_code'] == 'FILE2':
            raise ErrorFILE2(data['description'])
        
        #La cuota maxima de almacenamiento de ficheros se ha superado
        elif data['error_code'] == 'FILE3':
            raise ErrorFILE3(data['description'])

        #El ID de ese usuario no existe
        elif data['error_code'] == 'USER_ID1':
            raise ErrorUSER_ID1(data['description'])
        
        #No se ha encontrado el usuario con esos datos en la busqueda
        elif data['error_code'] == 'USER_ID2':
            raise ErrorUSER_ID2(data['description'])

        #Los argumentos de la peticion HTTP son erroneos
        elif data['error_code'] == 'ARGS1':
            raise ErrorARGS1(data['description'])

        else:
            print("Error desconocido")

