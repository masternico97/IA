#############################################################
# FILE: cifrar.py
#
#
# AUTHOR:  Jorge Gutierrez Diaz
#           Patricia Losana Ferrer
#
# DESCRIPTION: la clase Cifrar gestiona las funcionalidad de 
#              cifrado y firma de archivos
#
#############################################################

from Crypto.Signature import *
from Crypto.Hash import SHA256
from Crypto.PublicKey import RSA
from Crypto.Cipher import AES, PKCS1_OAEP
from Crypto import Random
import json, requests
from excepciones import *
from base64 import b64decode
import os
#from Crypto.Util import Padding

#Token de autenticacion 
#La descripcion del API especifica que la cabecera debe ser
# Autorization: Bearer [Token] (por eso incluimos aqui el bearer)
TOKEN = "Bearer fAB65b7310c2aE9F"

#Tamanyo de la firma
SIZE_SIGN = 256

class Cifrar:
    

    def __init__(self):
        sym = os.urandom(32)
        self.symKey = SHA256.new(sym).digest()

    ##########################################################
    # METODO: firmarArchivo(self, file)
    # ARGS_IN: self: objeto Cifrar
    #          file: archivo a firmar
    # DESCRIPCION: Dado un archivo, crea su hash y firma con la clave 
    #              privada del emisor 
    #
    # ARGS_OUT: PKCS1_v1_5.new(key).sign(h): archivo firmado
    #
    ##########################################################
    def firmarArchivo(self, file):
        #Obtencion de la clave privada
        key = RSA.importKey(open("miKey.bin", "rb").read())
        
        #Creacion del objeto hash de la clave privada
        h = SHA256.new(open(file, "rb").read())
        
        #Retorno del archivo firmado
        return PKCS1_v1_5.new(key).sign(h)

    ##########################################################
    # METODO: cifrarArchivo(self, message)
    # ARGS_IN: self: objeto Cifrar
    #          message: archivo a cifrar
    # DESCRIPCION: Dado un archivo, lo cifra en modo CBC sin firmar
    #
    # ARGS_OUT: iv + cipher.encrypt(message): vector de iniciacion +
    #                                         mensaje cifrado
    #
    ##########################################################
    def cifrarArchivo(self, message):
        
        #Padding al mensaje para que sea multiplo de 16
        message = self._pad(open(message, "rb").read())
        
        #Generacion aleatoria del vector de iniciacion (iv)
        iv = Random.new().read(AES.block_size)
        
        #Cifrado del mensaje en modo CBC
        cipher = AES.new(self.symKey, AES.MODE_CBC, iv)
        
        #Retorno del mensaje cifrado junto con el vector
        return iv + cipher.encrypt(message)

    ##########################################################
    # METODO: cifrarFirmaArchivo: (self, message, sign)
    # ARGS_IN: self: objeto Cifrar
    #          message: archivo a cifrar
    #          sign: firma del emisor
    # DESCRIPCION: Dado un archivo y su firma, los cifra en modo CBC
    #
    # ARGS_OUT: iv + cipher.encrypt(sign + message): vector de iniciacion +
    #                                                (mensaje + firma) cifrados
    #
    ##########################################################
    def cifrarFirmaArchivo(self, message, sign):
        
        #Padding al mensaje para que sea multiplo de 16
        message = self._pad(open(message, "rb").read())
        
        #Generacion aleatoria del vector de iniciacion (iv)
        iv = Random.new().read(AES.block_size)
        
        #Cifrado del mensaje en modo CBC
        cipher = AES.new(self.symKey, AES.MODE_CBC, iv)
        
        #Retorno de la firma y mensaje cifrados junto con el vector
        return iv + cipher.encrypt(sign + message)

    ##########################################################
    # METODO: cifrarClaveSimetrica(self, recKey) 
    # ARGS_IN: self: objeto Cifrar
    #          recKey: clave publica del receptor del mensaje
    #
    # DESCRIPCION: Cifra una clave simetrica con la clave publica 
    #               del receptor del mensaje
    #
    # ARGS_OUT: cipher.encrypt(self.symKey): clave simetrica cifrada
    #
    ##########################################################
    def cifrarClaveSimetrica(self, recKey):

        #Obtencion de la clave publica del receptor
        key = RSA.importKey(recKey)
        
        #Cifrado de la clave del receptor
        cipher = PKCS1_OAEP.new(key)
        return cipher.encrypt(self.symKey)


    ##########################################################
    # METODO: cifrar(self, message)
    # ARGS_IN: self: objeto Cifrar
    #          message: mensaje a cifrar
    #
    # DESCRIPCION: Cifra el archivo y la firma
    #
    # ARGS_OUT: self.cifrarFirmaArchivo(message, sign): mensaje y firma
    #                                                   cifrados
    #
    ##########################################################
    def cifrar(self, message):
        #Llamada a firmar archivo (primero firma, luego cifra)
        sign = self.firmarArchivo(message)
        #Llamada a cifrar archivo y firma
        return self.cifrarFirmaArchivo(message, sign)


    ##########################################################
    # METODO: descifrar(self, secret, srcKey)
    # ARGS_IN: self: objeto Cifrar
    #          secret: mensaje cifrado
    #          srcKey: clave privada
    #
    # DESCRIPCION: Descifra el archivo cifrado 
    #
    # ARGS_OUT: message: mensaje en claro
    #
    ##########################################################
    def descifrar(self, secret, srcKey):
        
        #Obtencion de la clave privada
        privateKey = RSA.importKey(open("miKey.bin", "rb").read())
        key = RSA.importKey(srcKey)

        #Obtencion de la clave simetrica del mensaje (del bit 0 al bit 255)
        sym = secret[:SIZE_SIGN]
        
        #Actualizacion del mensaje secreto (a partir del bit 256)
        secret = secret[SIZE_SIGN:]
        
        #Descifrado de la clave privada 
        cipher = PKCS1_OAEP.new(privateKey)
        ciphertext = cipher.decrypt(sym)
    
        #Obtencion del vector de inicializacion (iv) dentro del mensaje secreto
        #(tamanyo del bloque definido por la libreria AES)
        iv = secret[:AES.block_size]
        split = secret[AES.block_size:]

        #Cipher va a guardar el valor del vector de iniciacion
        cipher = AES.new(ciphertext, AES.MODE_CBC, iv)
        
        #Descifrado del mensaje utilizando cipher
        signMess = cipher.decrypt(split)

        #Obtencion de la firma descifrada (del bit 0 al bit 255 de signMess)
        signature = signMess[:SIZE_SIGN]
        
        #Obtencion del mensaje descifrado (a partir del bit 256)
        message = signMess[SIZE_SIGN:]
        
        #Llamada a la funcion unpad
        message = self._unpad(message)
        
        #Obtencion del hash del mensaje para validar la firma
        h = SHA256.new(message)

       #Verificacion de que la firma es valida
        try:
            PKCS1_v1_5.new(key).verify(h, signature)
            print("The signature is valid.")

        except (ValueError, TypeError):
            print("The signature is not valid.")
            return

        return message


    ##########################################################
    # METODO: subirServidor(self, message) 
    # ARGS_IN: self: objeto Cifrar
    #          message: mensaje en claro
    #
    # DESCRIPCION: Sube el archivo al servidor
    #
    # ARGS_OUT: success (subido correctamente) o error
    #
    ##########################################################
    def subirServidor(self, message):

        #Peticion al servidor (/files/upload)
        url = 'https://vega.ii.uam.es:8080/api/files/upload'
        datos = {
            'ufile': open(message,"rb")
        }
        cabeceras = {
            'Authorization': TOKEN
        }
        
        #Envio de la peticion
        r = requests.post(url, files=datos, headers=cabeceras)
        
        #Parseo de la respuesta de la peticion por estar en JSON
        data = json.loads(r.content.decode('utf-8'))
        
        #Comprobacion de que la peticion http fue correcta
        if r.status_code == 200:
            print("File successfully uploaded with ID "+data['file_id']+"") 
            return
        #Si la peticion fue erronea, comprobacion del error
        else:
            self.tratarError(r)


    ##########################################################
    # METODO: bajarServidor(self, idFile)
    # ARGS_IN: self: objeto Cifrar
    #          idFile: id del fichero a bajar
    #
    # DESCRIPCION: Descarga un archivo del servidor
    #
    # ARGS_OUT: success (bajado correctamente) o error
    #
    ##########################################################
    def bajarServidor(self, idFile):

        #Peticion al servidor (/files/download)
        url = 'https://vega.ii.uam.es:8080/api/files/download'
        datos = {
            'file_id': idFile
        }
        cabeceras = {
            'Authorization': TOKEN,
            'Content-type': 'application/json'
        }
        #Envio de la peticion
        r = requests.post(url, data=json.dumps(datos), headers=cabeceras)

        #Comprobacion de que la peticion HTTP fue correcta
        if r.status_code == 200:
            return r.content
        #Si la peticion fue erronea, comprobacion del error
        else:
            self.tratarError(r)


    ##########################################################
    # METODO: tratarError(self, data)
    # ARGS_IN: self: objeto Cifrar
    #          data: error
    #
    # DESCRIPCION: Lanza la excepcion del error correspondiente 
    #   y crea un objeto del tipo Error que corresponda 
    #   (excepciones.py)
    #
    # ARGS_OUT: -
    #
    ##########################################################
    
    def tratarError(self, data):

        #Token de usuario incorrecto
        if data['error_code'] == 'TOK1':
            raise ErrorTOK1(data['description'])
        
        #Token de usuario caducado, se debe solicitar uno nuevo
        elif data['error_code'] == 'TOK2':
            raise ErrorTOK2(data['description'])
        
        #Falta cabecera de autenticacion
        elif data['error_code'] == 'TOK3':
            raise ErrorTOK3(data['description'])

        #Se supera el tamanyo maximo de fichero
        elif data['error_code'] == 'FILE1':
            raise ErrorFILE1(data['description'])
        
        #El ID del fichero no es correcto
        elif data['error_code'] == 'FILE2':
            raise ErrorFILE2(data['description'])
        
        #La cuota maxima de almacenamiento de ficheros se ha superado
        elif data['error_code'] == 'FILE3':
            raise ErrorFILE3(data['description'])

        #El ID de ese usuario no existe
        elif data['error_code'] == 'USER_ID1':
            raise ErrorUSER_ID1(data['description'])
        
        #No se ha encontrado el usuario con esos datos en la busqueda
        elif data['error_code'] == 'USER_ID2':
            raise ErrorUSER_ID2(data['description'])

        #Los argumentos de la peticion HTTP son erroneos
        elif data['error_code'] == 'ARGS1':
            raise ErrorARGS1(data['description'])

        else:
            print("Error desconocido")


    ##########################################################
    # METODO: _pad(self, s) 
    # ARGS_IN: self: objeto Cifrar
    #          s: mensaje a rellenar
    #
    # DESCRIPCION: Rellena el mensaje s con bytes al final para que sea
    #   multiplo de 16 (necesario para que AES pueda cifrar)
    #
    # ARGS_OUT: s: mensaje relleno
    #   
    ##########################################################
    def _pad(self, s):
        length = 16 - (len(s) % 16)
        s += bytes([length]) * length
        return s

    ##########################################################
    # METODO: _unpad(self, s)
    # ARGS_IN: self: objeto Cifrar
    #          s: mensaje a eliminar el pad
    #
    # DESCRIPCION:  Elimina los bytes que se rellenaron con _pad en el
    #               mensaje s
    #
    # ARGS_OUT: s: mensaje sin el rellenado de bytes
    #   
    ##########################################################
    def _unpad(self, s):
        return s[:-s[-1]]