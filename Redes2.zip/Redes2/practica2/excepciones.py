#############################################################
# Fichero: excepciones.py
#
# Autores:  Jorge Gutierrez Diaz
#           Patricia Losana Ferrer
#
# Descr:    Todos los posibles codigos de error devueltos por
#			el API
#############################################################

##########################################################
# Clase ERRORRedes: 
#   Clase principal de excepciones (todas heredaran de ella)
#   
##########################################################
class ERRORRedes(Exception):
		pass


##########################################################
# Clase ErrorTOK1: 
#    	Token de usuario incorrecto
#   
##########################################################
class ErrorTOK1(ERRORRedes):
	#Constructor de ErrorTOK1
	def __init__(self, desc):
		self.desc = desc

	#Metodo para imprimir el error
	def __str__(self):
		print(self.desc)


##########################################################
# Clase ErrorTOK2: 
#   Token de usuario caducado, se debe solicitar uno nuevo.
#   
##########################################################
class ErrorTOK2(ERRORRedes):
	#Constructor de ErrorTOK2
	def __init__(self, desc):
		self.desc = desc
		
	#Metodo para imprimir el error	
	def __str__(self):
		print(self.desc)


##########################################################
# Clase ErrorTOK3: 
#   Falta cabecera de autenticación. No se ha incluido la 
#	cabecera o esta tiene un forma incorrecto.
#   
##########################################################
class ErrorTOK3(ERRORRedes):
	
	#Constructor de ErrorTOK3
	def __init__(self, desc):
		self.desc = desc
		
	#Metodo para imprimir el error
	def __str__(self):
		print(self.desc)


##########################################################
# Clase ErrorFILE1: 
#   Se ha supera el tamaño máximo permitido en la subida 
#	de un fichero (50Kb)
#   
##########################################################
class ErrorFILE1(ERRORRedes):
	#Constructor de ErrorFILE1
	def __init__(self, desc):
		self.desc = desc
	
	#Metodo para imprimir el error
	def __str__(self):
		print(self.desc)


##########################################################
# Clase ErrorFILE2: 
#   El ID de fichero proporcinado no es correcto (el fichero 
#	no existe o el usuario no disponde permisos para acceder 
#	a él)
#   
##########################################################
class ErrorFILE2(ERRORRedes):
	#Constructor de ErrorFILE2
	def __init__(self, desc):
		self.desc = desc
		
	#Metodo para imprimir el error
	def __str__(self):
		print(self.desc)


##########################################################
# Clase ErrorFILE3: 
#   La cuota máxima de almacenamiento de ficheros ha sido 
#	superada (20)
#   
##########################################################
class ErrorFILE3(ERRORRedes):
	#Constructor de ErrorFILE3
	def __init__(self, desc):
		self.desc = desc
		
	#Metodo para imprimir el error
	def __str__(self):
		print(self.desc)


##########################################################
# Clase ErrorUSER_1: 
#   El ID  de usuario proporcionado no existe
#   
##########################################################
class ErrorUSER_1(ERRORRedes):
	#Constructor de ErrorUSER_1
	def __init__(self, desc):
		self.desc = desc
	
	#Metodo para imprimir el error
	def __str__(self):
		print(self.desc)


##########################################################
# Clase ErrorUSER_2: 
#   No se ha encontrado el usuario con los datos 
#	proporcionados para la búsqueda con la función search.
#   
##########################################################
class ErrorUSER_2(ERRORRedes):
	#Constructor de ErrorUSER_2
	def __init__(self, desc):
		self.desc = desc
		
	#Metodo para imprimir el error
	def __str__(self):
		print(self.desc)
		
		
##########################################################
# Clase ErrorARGS1: 
#    	Los argumentos de la petición HTTP son erróneos
#   
##########################################################
class ErrorARGS1(ERRORRedes):

	#Constructor de ErrorARGS1
	def __init__(self, desc):
		self.desc = desc

	#Metodo para imprimir el error
	def __str__(self):
		print(self.desc)