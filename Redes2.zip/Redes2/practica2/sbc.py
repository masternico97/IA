#############################################################
# FILE: sbc.py
#
#
# AUTHOR:   Jorge Gutierrez Diaz
#           Patricia Losana Ferrer
#
# DESCRIPTION: la clase SecureBoxClient se encarga de parsear los
#           argumentos y llamar al resto de funcionalidades del programa
#
#############################################################

from identidad import Identidad
from cifrar import Cifrar
import os
import argparse



class SecureBoxClient:


    ##########################################################
    # METODO: parsearArgumetos(self)
    # ARGS_IN: self: objeto SecureBoxClient
    #
    # DESCRIPCION: Recibe y parsea los arguemtos pasados por terminal. Controla
    #           que los argumentos estan escritos correctamente y sean del tipo
    #           adecuado
    #       
    # ARGS_OUT: args: Argumentos parseados
    #
    ##########################################################
    def parsearArgumentos(self):
        #Parseamos los argumentos
        parser = argparse.ArgumentParser(description='Procesamos los comandos del cliente')
        #Creamos un grupo de arguemntos excluyentes entre si
        group1 = parser.add_mutually_exclusive_group() 
        group1.add_argument('--create_id', nargs=2, help='crear id')  
        group1.add_argument('--search_id', help='buscar id')    
        group1.add_argument('--delete_id', help='borrar id')
        group1.add_argument('--encrypt', help='ciframos el fichero')  
        group1.add_argument('--sign', help='firmamos el fichero')    
        group1.add_argument('--enc_sign', help='firmamos y ciframos el fichero')
        group1.add_argument('--list_files', nargs='?', const=True, help='listar todos los ficheros enviados por el usuario')
        group1.add_argument('--delete_file', help='elimina el fichero pedido del servidor')
        #Creamos un grupo que solo permite llamadas cuando se incluyen ambos argumentos
        #Este grupo corresponde a los comanods de subida del servidor
        group2 = parser.add_argument_group()
        group2.add_argument('-dest_id', '--dest_id', help='ID del destinatario')
        group2.add_argument('-upload', '--upload', help='fichero a enviar') 
        #Creamos un grupo que solo permite llamadas cuando se incluyen ambos argumentos
        #Este grupo corresponde a los comanods de bajada del servidor
        group3 = parser.add_argument_group()
        group3.add_argument('-source_id', '--source_id', help='ID del emisor')
        group3.add_argument('-download', '--download', help='id del fichero a descargar')  
        
        args = parser.parse_args()

        return args

    ##########################################################
    # METODO: comprobarArg(self, args)
    # ARGS_IN: self: objeto SecureBoxClient
    #          args: argumentos parseados
    #
    # DESCRIPCION:  Interpretamos los argumentos parseados y realizamos 
    #           las acciones correspondientes.
    #       
    #
    # ARGS_OUT: -
    #
    ##########################################################
    def comprobarArg(self, args):

        #Creamos el usuario y lo registramos en el servidor
        if args.create_id:
            print("Has escogido la opcion --create_id")    
            user = Identidad()   
            response = user.registrarUsuario(args.create_id[0], args.create_id[1])           
            
        #Buscamos a un usuario
        elif args.search_id:
            print("Has escogido la opcion --search_id\n")
            user = Identidad()
            response = user.buscarUsuario(args.search_id)
            
        #Eliminamos al usuario
        elif args.delete_id:
            print("Has escogido la opcion --delete_id")
            user = Identidad()
            response = user.eliminarUsuario(args.delete_id)

        #Ciframos un mensaje(sin firmar)
        elif args.encrypt:
            print("Has escogido la opcion --encrypt")
            cipher = Cifrar() 
            print(cipher.cifrarArchivo(args.encrypt))       
            return
        
        #Firmamos un mensaje
        elif args.sign:
            print("Has escogido la opcion --sign")
            cipher = Cifrar()  
            print(cipher.firmarArchivo(args.sign))         
            return 

        #Ciframos y firmamos un mensaje
        elif args.enc_sign:
            print("Has escogido la opcion --enc_sign")
            cipher = Cifrar()
            sign = cipher.firmarArchivo(args.enc_sign)
            print(cipher.cifrarFirmaArchivo(args.enc_sign, sign))
            return 

        #Subimos al servidor un mensaje cifrado
        elif args.upload or args.dest_id:
            print("Has escogido la opcion --upload")
            #Si el mensaje o id del receptor es None, devolvemos error
            if args.dest_id == None or args.upload == None:
                print("sbc.py: error: the following arguments are required: --dest_id, --upload")
                return
        
            user = Identidad()
            cipher = Cifrar()
            #Conseguimos la clave publica del receptor
            destKey = user.conseguirClavePublica(args.dest_id)
            #Ciframos el mensaje
            message = cipher.cifrar(args.upload)
            #Ciframos la clave simetrica
            sym = cipher.cifrarClaveSimetrica(destKey)
            if sym == None:
                print("Error durante el cifrado del fichero.")
                return
            #Cocatenamos el cifrado de la clave simetrica con el mensaje cifrado
            total = sym + message
            #Guardamos el mensaje en el mismo fichero del mensaje
            f = open("cifer.bin", "wb")
            f.write(total)
            f.close()
            #Subimos al servidor el mensaje
            cipher.subirServidor("cifer.bin")


        #Descargamos del servidor el fichero deseado
        elif args.download or args.source_id:
            print("Has escogido la opcion --download")
            #Si el id del mensaje o id del emisor es None, devolvemos error
            if args.source_id == None or args.download == None:
                print("sbc.py: error: the following arguments are required: --download, --source_id")
                return
 
            user = Identidad()
            cipher = Cifrar()
            #Obtenemos la clave publica del emisor
            sourceKey = user.conseguirClavePublica(args.source_id)
            #Descargamos del servidor el fichero deseado
            message = cipher.bajarServidor(args.download)
            #Desciframos el mensaje
            descipher = cipher.descifrar(message, sourceKey)
            #Guardamos el mensaje
            f = open("secret.bin", "wb")
            f.write(descipher)
            f.close()
            
        #Imprimimos la lista de ficheros subidos al servidor
        elif args.list_files:
            print("Has escogido la opcion --list_files")
            user = Identidad()
            return user.listarFicheros()
            
        #Eliminamos el fichero especificado del servidor    
        elif args.delete_file:
            print("Has escogido la opcion --delete_file")
            user = Identidad()
            return user.eliminarFichero(args.delete_file)
            
            
        else:
            print("Default")


if __name__ == '__main__':

    sbc = SecureBoxClient()
    argumentos = sbc.parsearArgumentos()
    sbc.comprobarArg(argumentos)

