<?php

	$parts = parse_url($argv[1]);
	parse_str($parts['query'], $query);


	echo 'Saludos '.$query['name'].'!';

?>