import sys
from urllib.parse import urlsplit, parse_qsl

cadena = str(sys.argv[1])

split = urlsplit(cadena)

var = dict(parse_qsl(split.query))

suma = int(var['a']) + int(var['b'])

print(suma)
