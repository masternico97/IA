/**********
* FILE:   servidor_concurrente.c
*
* AUTHOR: Jorge Gutierrez
*         Patricia Losana
*
* DESCRIPTION: codigo para un servidor simple concurrente
*/


#include "picohttpparser.h"
#include "server_library.h"
#define TAM_MENSAJE 200

typedef struct {
    const char *extension;
    const char *mime_type;
} mime_map;

mime_map meme_types [] = {
    {".gif", "image/gif"},
    {".htm", "text/html"},
    {".html", "text/html"},
    {".py", "text/html"},
    {".php", "text/html"},
    {".jpeg", "image/jpeg"},
    {".jpg", "image/jpeg"},
    {".docx", "application/msword"},
    {".doc", "application/msword"},
    {".pdf", "application/pdf"},
    {".txt", "text/plain"},
    {".mpg", "video/mpeg"},
    {".mpeg", "video/mpeg"},
    {NULL, NULL},
};

/********
* FUNCION: int initiate_server(int prt_src)
* ARGS_IN: prt_src - puerto origen
* DESCRIPCIÓN: Inicia el socket del servidor en el puerto origen indicado
*               Llama a las funciones especificas de socket:
*                   socket (int family, int type, int protocol)
*                   bind (int server_socket, const struct sockaddr_in *dir_server, int size)
*                   listen (int server_socket, int queue-size)
*
*
* ARGS_OUT: int sockval - valor de referencia al socket iniciado
********/
int initiate_server(int prt_src){
	int sockval;   /*valor de referencia al socket*/
	struct sockaddr_in dir_serv; /*direccion del servidor*/

    /*Utilizacion de syslog para informar de la creacion del socket a traves del demonio*/
    syslog (LOG_INFO, "Creating socket");

    /*Inicializacion del socket con ÂF_INET (IPv4) y SOCK_STREAM (TCP)*/
    if ((sockval = socket(AF_INET, SOCK_STREAM, 0)) < 0){
        syslog(LOG_ERR, "Error creating socket");
        return -1;
    }

    /* Limpiamos la posicion de memoria donde residira la direccion del servidor*/
    bzero((char *) &dir_serv, sizeof(dir_serv));


    dir_serv.sin_family = AF_INET;    /*Especificamos la familia de direcciones a usar (Todas las disponibles en Internet)*/
    dir_serv.sin_addr.s_addr = INADDR_ANY;    /*Asi cogera cualquier IP*/
    dir_serv.sin_port = htons(prt_src);    /*Abrimos el puerto pasado por argumento*/

    syslog(LOG_INFO, "Binding socket"); /*Escribe en el log*/


    /*Apertura del socket para que escuche en la IP y puerto establecidos */
    if(bind(sockval, (struct sockaddr *) &dir_serv, sizeof(dir_serv)) < 0){
        syslog(LOG_ERR, "Error binding socket");
        return -1;
    }

    syslog(LOG_INFO, "Listening connections"); /*Escribe en el log*/

    /*Llamada (bloqueante) a la funcion de socket listen: esperara a la llegada de una peticion*/
    if (listen(sockval, MAX_CONNECTIONS) < 0){
    	syslog(LOG_ERR, "Error listening");
    	return -1;
    }

    return sockval;
}


/********
* FUNCION: int accept_request(int socketfd, struct sockaddr * cliaddr, socklen_t * clilen)
* ARGS_IN: int socketfd - socket en el que esta escuchando el servidor
*          struct sockaddr * cliaddr - estructura que contiene la direccion del cliente
*          socklen_t * clilen - estructura que contiene el tamaño de la direccion del cliente
* DESCRIPCIÓN: Acepta la peticion recibida del cliente
*               Llama a la funcion especifica de socket:
*                   accept (socketfd, struct sockaddr * cliaddr, socklen_t * clilen)
*
* ARGS_OUT: int connfd - valor de referencia a la conexion con el cliente
********/
int accept_request(int socketfd, struct sockaddr * cliaddr, socklen_t * clilen){
	int connfd;
	syslog (LOG_INFO, "Accepting connection"); /*Escribe en el log*/
    /*Llamada a la funcion de socket accept: acepta la peticion de un cliente*/
	if(( connfd = accept(socketfd, cliaddr, clilen)) < 0){
            syslog(LOG_ERR,"Error accepting connection");
            return -1;
        }

    return connfd;
}


/********
* FUNCION: int process_request(int connfd)
* ARGS_IN: int connfd - valor de la conexion cliente-servidor
* DESCRIPCIÓN: Procesa la peticion del cliente
*               Llama a la funcion especifica de socket:
*                   recv(int client_socket, const void *msg, size_t len, int flags)
* ARGS_OUT: int 0 - peticion procesada con exito
*           int -1 - ha habido algun problema en el procesamiento
********/
int process_request(int connfd){

    char buf[4096], ruta[100], metodo[100], *method, *path;
    int pret, minor_version;
    struct phr_header headers[100];
    size_t buflen = 0, prevbuflen = 0, method_len, path_len, num_headers;
    ssize_t rret;

    syslog (LOG_INFO, "Recieving from client"); /*Escribe en el log*/

    while(1){
        /*Llamada a funcion especifica de socket que recibe un mensaje del servidor. 
         * Args:
         *  client_socket: parametro devuelto por la funcion socket()
         *  msg: mensaje a enviar
         *  len: tamaño del mensaje
         *  flags: en principio 0 (si queremos tener algun flag activado)*/
   	    while ((rret = recv(connfd, buf + buflen, sizeof(buf) - buflen, 0)) == -1 && errno == EINTR);


        if (rret <= 0){
            return -1;
        }
        prevbuflen = buflen;
        buflen += rret;

        /* parsea la peticion haciendo uso de la libreria picohttparsser */
        num_headers = sizeof(headers) / sizeof(headers[0]);
        pret = phr_parse_request(buf, buflen, &method, &method_len, &path, &path_len,
                                 &minor_version, headers, &num_headers, prevbuflen);
        if (pret > 0){
            break; /* parseo correcto de la peticion */
        }
        else if (pret == -1){
            syslog(LOG_ERR,"ParseError\n");
            return -1;
        }
        /* peticion incompleta, continua dentro del bucle de parseado */
        assert(pret == -2);
        if (buflen == sizeof(buf)){
            syslog(LOG_ERR,"RequestIsTooLongError\n");
            return -1;
        }
    }
    /*Obtenemos el verbo*/
    sprintf(metodo, "%.*s", (int)method_len, method);
    /*Obtenemos la ruta (si no hay ruta dirige a index.html)*/
    if (path_len > 1) {
        sprintf(ruta, "%.*s", (int)path_len, path);
    } else {
        sprintf(ruta, "/index.html");
    }

    /*Comparamos los verbos conocidos con el recibido*/
    if(strcmp("GET", metodo) == 0){
        crearRespuestaGET(connfd, ruta); /*Llamada a la funcion crearRespuesta para el metodo GET*/
    } else if(strcmp("POST", metodo) == 0){
    	crearRespuestaPOST(connfd, ruta, buf); /*Llamada a la funcion crearRespuesta para el metodo POST*/
    } else if(strcmp("OPTIONS", metodo) == 0){
        crearRespuestaOPTIONS(connfd); /*Llamada a la funcion crearRespuesta para el metodo OPTIONS*/
    } else {
        respuestaErr400(connfd); /*Si no es ninguno de los verbos conocidos, error400*/
    }
    return 0;
}

/********
* FUNCION: int crearRespuestaGET(int connfd, char* ruta)
* ARGS_IN: int connfd - valor de la conexion cliente-servidor
*          char* ruta - puntero a la ruta que ha solicitado el cliente
* DESCRIPCIÓN: Crea la respuesta a la peticion del cliente si el verbo fue GET
* ARGS_OUT: int 0 - peticion procesada con exito
*           int -1 - ha habido algun problema en el procesamiento
********/
int crearRespuestaGET(int connfd, char* ruta){

    char respuesta[8000];
	char buf[100], date[100], type[100], raiz[100];
	char last[100], length[100], serv_name[100], *root;
  	time_t now = time(0);
  	struct tm tm = *gmtime(&now);
    struct stat attr;

    sprintf(raiz , "%s", obtenerPathFichero(ruta));
    sprintf(serv_name, "Server: %s\r\n", obtenerNombreServidor());
    /*https://stackoverflow.com/questions/7548759/generate-a-date-string-in-http-response-date-format-in-c*/
    /*https://stackoverflow.com/questions/10446526/get-last-modified-time-of-file-in-linux*/
    /*https://stackoverflow.com/questions/230062/whats-the-best-way-to-check-if-a-file-exists-in-c-cross-platform*/

    /*En caso de que la peticion sea un fichero .py o .php, guarda en raiz
      la cadena que haya despues del token '?'*/
    if(strstr(raiz, ".py") != NULL || strstr(raiz, ".php") != NULL){
        strcpy(buf, raiz);
        root = strtok(buf, "?");
        strcpy(raiz, buf);
        bzero(buf, 100);
    }

    /*Si el fichero existe, entra aqui, si no, error404*/
    if(access(raiz, F_OK) != -1) {

        /*Escribe la cabecera de respuesta con los valores:
            Date:
            Content-type:
            Last-modified:
            Content-length:*/
        root = obtenerFechaActual(); /*Obtiene la fecha para escribirla dentro de la cabecera*/
        sprintf(date, "Date: %s\r\n", root);
        free(root);

        /*Obtiene el tipo de fichero para escribirlo dentro de la cabecera*/
        root = obtenerTypeFichero(raiz);
        if(root == NULL){
            syslog(LOG_ERR,"Error al obtener el tipo de fichero\n");
            return -1;
        }
        sprintf(type, "Content-type: %s\r\n\r\n", root);
        free(root);

    	stat(raiz, &attr);
        /*Obtiene la ultima fecha de modificacion para escribirla dentro de la cabecera*/
	    strftime(buf, sizeof buf, "%a, %d %b %Y %X GMT", gmtime(&(attr.st_mtime)));
	    sprintf(last, "Last-Modified: %s\r\n", buf);
        sprintf(length, "Content-length: %d\r\n", attr.st_size);

        /*Si el fichero a servir es de python o de php entra aqui*/
        if(strstr(ruta, ".py") != NULL || strstr(ruta, ".php") != NULL){
            /*Llama a la funcion que trata los scripts*/
            root = respuestaScriptGET(ruta, raiz);
            if(root == NULL){
                syslog(LOG_ERR,"Error al obtener respuesta de script\n");
                return -1;
            }
            /*sirve el contenido del fichero dentro de un html en el body de la respuesta*/
            sprintf(respuesta, "<!DOCTYPE html><html><body><h1>%s</h1></body></html>", root);
            free(root);
            sprintf(length, "Content-length: %d\r\n", strlen(respuesta));
            /*Llamada a la funcion enviarCabecera*/
            enviarCabecera(connfd, serv_name, date, last, length, type);
            /*Llamada a la funcion especifica de socket 'send' para enviar el resultado al cliente*/
            send(connfd, respuesta, strlen(respuesta), 0);
            return 1;

        } else if(strstr(type, "image") != NULL || strstr(type, "video") != NULL){
            /*Si el fichero a servir es de tipo imagen o video entra aqui*/
            enviarCabecera(connfd, serv_name, date, last, length, type);
            enviarRespuesta(connfd, "rb", raiz);

        } else {
        /*Si no es de tipo imagen entra aqui*/
            enviarCabecera(connfd, serv_name, date, last, length, type);
            enviarRespuesta(connfd, "r", raiz);
        }

    } else {
        /*El fichero solicitado no se encuentra dentro del directorio htmlfiles del servidor*/
        respuestaErr404(connfd);
    }

    return 0;
}


/********
* FUNCION: int crearRespuestaPOST(int connfd, char* ruta, char* args)
* ARGS_IN: int connfd - valor de la conexion cliente-servidor
*          char* ruta - puntero a la ruta que ha solicitado el cliente
*          char* args - puntero a los argumentos a utilizar en el post
* DESCRIPCIÓN: Crea la respuesta a la peticion del cliente si el verbo fue POST
* ARGS_OUT: int 0 - peticion procesada con exito
*           int -1 - ha habido algun problema en el procesamiento
********/
int crearRespuestaPOST(int connfd, char* ruta, char* args){

    char respuesta[8000];
    char date[100], type[100], raiz[100];
    char last[100], length[100], serv_name[100], *root;

    /*Escribe la cabecera de respuesta con los valores:
            Server:
            Date:
            Content-type:
            Last-modified:
            Content-length:*/
    sprintf(raiz , "%s", obtenerPathFichero(ruta));
    sprintf(serv_name, "Server: %s\r\n", obtenerNombreServidor());

    /*https://stackoverflow.com/questions/7548759/generate-a-date-string-in-http-response-date-format-in-c*/
    /*Si el fichero existe, entra aqui, si no, error404*/
    if(access(raiz, F_OK) != -1) {
        root = obtenerFechaActual(); /*Obtiene la fecha para escribirla dentro de la cabecera*/
        sprintf(date, "Date: %s\r\n", root);
        free(root);

        /*Obtiene el tipo de fichero para escribirlo dentro de la cabecera*/
        root = obtenerTypeFichero(raiz);
        if(root == NULL){
            syslog(LOG_ERR,"Error al obtener el tipo de fichero\n");
            return -1;
        }
        sprintf(type, "Content-type: %s\r\n\r\n", root);
        free(root);
        /*Obtiene la ultima fecha de modificacion para escribirla dentro de la cabecera*/
        root = obtenerLastModiFichero(raiz);
        if(root == NULL){
            printf("Error al obtener la fecha de modificacion\n");
            return -1;
        }
        sprintf(last, "Last-Modified: %s\r\n", root);
        free(root);
        
        /*Llamada a la funcion respuestaScriptPOST*/
        root = respuestaScriptPOST(raiz, args);
        if(root == NULL){
            printf("Error al obtener respuesta de script\n");
            return -1;
        }

        /*sirve el contenido del fichero dentro de un html en el body de la respuesta*/
        sprintf(respuesta, "<!DOCTYPE html><html><body><h1>%s</h1></body></html>", root);
        free(root);
        sprintf(length, "Content-length: %d\r\n", strlen(respuesta));

        /*Llamada a la funcion enviarCabecera*/
        enviarCabecera(connfd, serv_name, date, last, length, type);

        syslog (LOG_INFO, "Sending to client"); /*Escribe en el log*/
        /*Llamada a la funcion especifica de socket 'send' para enviar el resultado al cliente*/
        send(connfd, respuesta, strlen(respuesta), 0);
        return 1;

    } else {
        /*El fichero solicitado no se encuentra dentro del directorio htmlfiles del servidor*/
        respuestaErr404(connfd);
    }
    return 0;
}

/********
* FUNCION: int crearRespuestaOPTIONS(int connfd)
* ARGS_IN: int connfd - valor de la conexion cliente-servidor
* DESCRIPCIÓN: Crea la respuesta a la peticion del cliente si el verbo fue OPTIONS
* ARGS_OUT: int 0 - peticion procesada con exito
*           int -1 - ha habido algun problema en el procesamiento
********/
int crearRespuestaOPTIONS(int connfd){

    /*Variables que van a guardar todo el contenido de la cabecera*/
    char header200[100] = "HTTP/1.1 200 OK\r\n";
    char respuesta[8000];
    char date[100], allow[100];
    char length[100], serv_name[100];
    char *root;

    /*Escribe la cabecera de respuesta con los valores:
            Server:
            Date:
            Content-type:
            Last-modified:
            Content-length:*/
    sprintf(serv_name, "Server: %s\r\n", obtenerNombreServidor());
    root = obtenerFechaActual();
    sprintf(date, "Date: %s\r\n", root);
    free(root);
    sprintf(length, "Content-length: 0\r\n");
    sprintf(allow, "Allow: OPTIONS, GET, POST\r\n\r\n");


    sprintf(respuesta, "%s", header200);
    sprintf(respuesta + strlen(respuesta), "%s" , serv_name);
    sprintf(respuesta + strlen(respuesta), "%s" , date);
    sprintf(respuesta + strlen(respuesta), "%s" , length);
    sprintf(respuesta + strlen(respuesta), "%s" , allow);

    /*Llamada a funcion especifica de socket que envia un mensaje. 
         * Args:
         *  connfd: parametro de conexion con el cliente
         *  respuesta: mensaje a enviar
         *  len: tamaño del mensaje
         *  flags: en principio 0 (si queremos tener algun flag activado)*/
    if((send(connfd, respuesta, strlen(respuesta), 0)) < 0){
        syslog(LOG_ERR,"Error al enviar la cabecera al cliente.\n");
        return -1;
    }
    bzero(respuesta, 8000);
    return 1;
}


/********
* FUNCION: char* respuestaScriptGET(char* ruta, char* raiz)
* ARGS_IN: char* ruta - ruta al script
*          char* raiz - nombre del script
* DESCRIPCIÓN: Ejecuta el script con las variables pedidas y devuelve el resultado
* ARGS_OUT: char* buffer - resultado de la ejecucion del script
*        
********/
char* respuestaScriptGET(char* ruta, char* raiz){

    char exe[500];
    char *buffer = NULL;
    FILE* fp = NULL;

    /*Comprueba si el script es de python o php*/
    if(strstr(raiz, ".py") != NULL){
        /*si es tipo python escribe en exe la cadena python3 fichero ruta*/
        sprintf(exe, "python3 %s '%s'", raiz, ruta);
    } else {
        /*si es tipo php escribe en exe la cadena php5 fichero ruta*/
        sprintf(exe, "php5 %s '%s'", raiz, ruta);
    }

    /*Guarda en el fichero fp el resultado de ejecutar exe en terminal*/
    fp = popen(exe, "r");
    if(fp == NULL){
        syslog(LOG_ERR,"Error al iniciar el script\n");
        return NULL;
    }

    /*Reserva memoria dinamica para buffer (abarcara hasta 500 bytes)*/
    buffer = (char*)malloc(500*sizeof(char));
    if(buffer == NULL){
        syslog(LOG_ERR,"Error en reserva de memoria\n");
        fclose(fp);
        return NULL;
    }
    /*Guarda en buffer el contenido de fp*/
    fgets(buffer, 499, fp);
    fclose(fp);
    return buffer;
}


/********
* FUNCION: char* respuestaScriptPOST(char* ruta, char* buf)
* ARGS_IN: char* ruta - ruta al script
*          char* buf - argumentos del script
* DESCRIPCIÓN: Ejecuta el script con las variables pedidas y devuelve el resultado
* ARGS_OUT: char* buffer - resultado de la ejecucion del script
*        
********/
char* respuestaScriptPOST(char* raiz, char* buf){

    char exe[500], cpy[500], body[500];
    char *buffer = NULL;
    char *aux;
    FILE* fp = NULL;

    /*guarda buf en cpy (para no modificar el body original)*/
    sprintf(cpy, "%s", buf);
    /*rompe cpy usando como token el primer \r\n\r\n*/
    aux = strtok(cpy, "\r\n\r\n");

    /*guarda en body todo el contenido de aux sin los \r\n\r\n*/
    while(aux != NULL){
        bzero(body, 500);
        strcpy(body, aux);
        aux = strtok(NULL, "\r\n\r\n");
    }

    /*Comprueba si el script es de python o php*/
    if(strstr(raiz, ".py") != NULL){
        /*si es tipo python escribe en exe la cadena python3 fichero body*/
        sprintf(exe, "python3 %s '?%s'", raiz, body);
    } else {
        /*si es tipo php escribe en exe la cadena php5 fichero body*/
        sprintf(exe, "php5 %s '?%s'", raiz, body);
    }

    /*Guarda en el fichero fp el resultado de ejecutar exe en terminal*/
    fp = popen(exe, "r");
    if(fp == NULL){
        syslog(LOG_ERR,"Error al iniciar el script\n");
        return NULL;
    }
    /*Reserva memoria dinamica para buffer (abarcara hasta 500 bytes)*/
    buffer = (char*)malloc(500*sizeof(char));
    if(buffer == NULL){
        syslog(LOG_ERR,"Error en reserva de memoria\n");
        fclose(fp);
        return NULL;
    }
    /*Guarda en buffer el contenido de fp*/
    fgets(buffer, 499, fp);
    fclose(fp);
    return buffer;
}

/********
* FUNCION: int enviarCabecera(int connfd, char* serv_name, char* date,
                        char* last, char* length, char* type)
* ARGS_IN: int connfd - valor de la conexion con el cliente
*          char* serv_name - nombre del servidor
*          char* date - valor de la fehca
*          char* last - valor de ultima modificacion
*          char* length - valor del tamanyo
*          char* type - valor del tipo de fichero
* DESCRIPCIÓN: concatena los elementos de la cabecera y la envia con la funcion de socket send
* ARGS_OUT: int 0 - cabecera enviada con exito
*           int -1 - ha habido algun problema en el envio
********/
int enviarCabecera(int connfd, char* serv_name, char* date,
                        char* last, char* length, char* type){

    char respuesta[8000]; /*Variable que contendra la cabecera*/
    char header200[100] = "HTTP/1.1 200 OK\r\n";

    /*Concatenacion por orden de los elementos de la cabecera dentro de respuesta*/
    sprintf(respuesta, "%s", header200);
    sprintf(respuesta + strlen(respuesta), "%s" , serv_name);
    sprintf(respuesta + strlen(respuesta), "%s" , date);
    sprintf(respuesta + strlen(respuesta), "%s" , last);
    sprintf(respuesta + strlen(respuesta), "%s" , length);
    sprintf(respuesta + strlen(respuesta), "%s" , type);

    /*Llamada a funcion especifica de socket que envia un mensaje. 
         * Args:
         *  connfd: parametro de conexion con el cliente
         *  respuesta: mensaje a enviar
         *  len: tamaño del mensaje
         *  flags: en principio 0 (si queremos tener algun flag activado)*/
    if((send(connfd, respuesta, strlen(respuesta), 0)) < 0){
        syslog(LOG_ERR,"Error al enviar la cabecera al cliente.\n");
        return -1;
    }
    return 0;
}

/********
* FUNCION: int enviarRespuesta(int connfd, char* type, char* raiz)
* ARGS_IN: int connfd - valor de la conexion con el cliente
*          char* type - valor del tipo de fichero
*          char* raiz - valor del tamanyo
* DESCRIPCIÓN: concatena los elementos de la cabecera y la envia con la funcion de socket send
* ARGS_OUT: int 0 - cabecera enviada con exito
*           int -1 - ha habido algun problema en el envio
********/
int enviarRespuesta(int connfd, char* type, char* raiz){

    int fileLen = 0;
    char respuesta[8000];
    FILE* fp = NULL;

    /*Abre el fichero solicitado por el cliente*/
    fp = fopen(raiz, type);
    if(fp == NULL){
        syslog(LOG_ERR,"Error al abrir el archivo");
        return -1;
    }
    /*Llamada a funcion especifica de socket que envia un mensaje. 
         * Args:
         *  connfd: parametro de conexion con el cliente
         *  respuesta: mensaje a enviar
         *  len: tamaño del mensaje
         *  flags: en principio 0 (si queremos tener algun flag activado)*/
    while((fileLen = fread(respuesta, 1, 7999, fp)) > 0){
        send(connfd, respuesta, fileLen, 0);
        bzero(respuesta, 8000);
    }
    /*cierra el fichero y escribe en syslog que el send ha funcionado*/
    fclose(fp);
    syslog (LOG_INFO,"Mensaje enviado con exito");
    return 1;
}

/********
* FUNCION: char* obtenerPathFichero(char* ruta)
* ARGS_IN: char* ruta - ruta especificada en la peticion
* DESCRIPCIÓN: obtiene la ruta del fichero
* ARGS_OUT: char* root - ruta al fichero
********/
char* obtenerPathFichero(char* ruta){

    FILE* fp = NULL;
    char *root;
    char buf[100];
    char raiz[100];

    /*abre el fichero server.conf para obtener el directorio raiz (segunda linea)*/
    fp = fopen("server.conf", "r");
    if(fp == NULL){
        syslog(LOG_ERR,"Error al abrir el archivo\n");
        return NULL;
    }

    /*Lee la primera linea de server.conf*/
    fgets(buf, 100, fp);
    /*Lee la segunda linea de server.conf*/
    fgets(buf, 100, fp);
    /*Tokeniza buf por el primer espacio*/
    root = strtok(buf, " \n");
    /*Tokeniza buf por el segundo espacio*/
    root = strtok(NULL, " \n");
    /*Tokeniza buf por el tercer espacio (se queda con 'htmlfiles')*/
    root = strtok(NULL, " \n");
    /*Copia en raiz el valor de root*/
    strcpy(raiz, root);
    /*Copia en raiz, despues de root, el valor de ruta*/
    strcat(raiz, ruta);
    fclose(fp);
    sprintf(root, "%s", raiz);
    return root;
}

/********
* FUNCION: char* obtenerNombreServidor()
* ARGS_IN: - 
* DESCRIPCIÓN: obtiene el nombre del servidor
* ARGS_OUT: char* root - nombre del servidor
********/
char* obtenerNombreServidor(){

    FILE* fp = NULL;
    char *root;
    char buf[100];

    /*abre el fichero server.conf para obtener el nombre del servidor*/
    fp = fopen("server.conf", "r");
    if(fp == NULL){
        syslog(LOG_ERR,"Error al abrir el archivo\n");
        return NULL;
    }
    /*Lee la primera linea de server.conf*/
    fgets(buf, 100, fp);
    /*Lee la segunda linea de server.conf*/
    fgets(buf, 100, fp);
    /*Lee la tercera linea de server.conf*/
    fgets(buf, 100, fp);
    /*Lee la cuarta linea de server.conf*/
    fgets(buf, 100, fp);
    /*Lee la quinta linea de server.conf*/
    fgets(buf, 100, fp);
    fclose(fp);

    root = strstr(buf, "=");
    /*Guarda en root el valor despues del caracter '=' para el nombre del servidor*/
    root += 2;
    return root;
}

/********
* FUNCION: char* obtenerTypeFichero(char* raiz)
* ARGS_IN: char* raiz - el nombre del fichero
* DESCRIPCIÓN: obtiene el tipo de fichero que es raiz
* ARGS_OUT: char* aux - tipo del fichero raiz
********/
char* obtenerTypeFichero(char* raiz){

    /*Estructura con todas las extensiones conocidas por el servidor*/
    mime_map *map = meme_types; 
    char *dot;
    char buf[100];
    char *aux;

    /*Guarda en dot la extension de raiz a partir del punto*/
    dot = strrchr(raiz, '.');

    /*Mira cada una de las extensiones de map hasta que una coincida con dot*/
    while(map->extension){
        if(strcmp(map->extension, dot) == 0){
            /*Guarda en buf el tipo correspondiente a dot*/
            sprintf(buf, "%s", map->mime_type);
            break;
        }
        map++;
    }

    /*Guarda en aux el valor de buf*/
    aux = (char*)malloc(100*sizeof(char));
    if(aux == NULL){
        syslog(LOG_ERR,"Error en reserva de memoria\n");
        return NULL;
    }
    /*Copia en aux el valor de buf*/
    strcpy(aux, buf);
    return aux;
}

/********
* FUNCION: char* obtenerLastModiFichero(char* raiz)
* ARGS_IN: char* raiz - el nombre del fichero
* DESCRIPCIÓN: obtiene la fecha de ultima modificacion
* ARGS_OUT: char* aux - fecha de ultima modificacion del fichero raiz
********/
char* obtenerLastModiFichero(char* raiz){

    struct stat attr;
    char buf[100];
    char *aux;

    aux = (char*)malloc(100*sizeof(char));
    if(aux == NULL){
        syslog(LOG_ERR,"Error en reserva de memoria\n");
        return NULL;
    }

    /*Guarda la informacion del fichero raiz en la variable attr*/
    stat(raiz, &attr);
    /*Guarda en buf el valor de tiempo de attr*/
    strftime(buf, sizeof buf, "%a, %d %b %Y %X GMT", gmtime(&(attr.st_mtime)));
    /*Copia en aux el valor de buf*/
    strcpy(aux, buf);
    return aux;
}

/********
* FUNCION: char* obtenerFechaActual()
* ARGS_IN: -
* DESCRIPCIÓN: obtiene la fecha actual
* ARGS_OUT: char* aux - fecha actual
********/
char* obtenerFechaActual(){

    time_t now = time(0);
    struct tm tm = *gmtime(&now);
    char buf[100];
    char* date;

    date = (char*)malloc(100*sizeof(char));
    if(date == NULL){
        syslog(LOG_ERR,"Error en reserva de memoria\n");
        return NULL;
    }

    /*Guarda en buf el valor de tiempo*/
    strftime(buf, sizeof buf, "%a, %d %b %Y %X GMT", &tm);
    /*Copia en aux el valor de buf*/
    strcpy(date, buf);
    return date;
}


/********
* FUNCION: int respuestaErr400(int connfd)
* ARGS_IN: int connfd - valor de la conexion con el cliente        
* DESCRIPCIÓN: Envia al cliente el codigo de respuesta 400 (Bad Request)
* ARGS_OUT: int 0 - cabecera enviada con exito
*           int -1 - ha habido algun problema en el envio
********/
int respuestaErr400(int connfd){
    char *root;
    char serv_name[100], date[100], length[100];
    char connect[100], type[100], raiz[100];
    char respuesta[1200], cabecera[8000];
    FILE *fp = NULL;

    /*Guarda en raiz la ruta a Err400.html*/
    sprintf(raiz , "%s", obtenerPathFichero("/Errores/Err400.html"));

    /*Escribe la cabecera de respuesta con los valores:
            Server:
            Date:
            Content-type:
            Last-modified:
            Content-length:*/
    sprintf(serv_name, "Server: %s\r\n", obtenerNombreServidor());

    root = obtenerFechaActual();
    sprintf(date, "Date: %s\r\n", root);
    free(root);
    sprintf(connect, "Connection: Keep-Alive\r\n");
    sprintf(type, "Content-Type: text/html\r\n");
    
    /*Abre el fichero Err400.html*/
    fp = fopen(raiz, "r");
    if(fp == NULL){
        syslog(LOG_ERR,"Error al abrir el fichero %s\n", raiz);
        return -1;
    }
    fread(respuesta, 1199, 1, fp);
    fclose(fp);
    /*Escribe en la cabecera de la respuesta los elementos obtenidos antes*/
    sprintf(length, "Content-length: %d\r\n\r\n", strlen(respuesta));

    sprintf(cabecera, "HTTP/1.1 400 Bad Request\r\n");
    sprintf(cabecera + strlen(cabecera), "%s" , serv_name);
    sprintf(cabecera + strlen(cabecera), "%s" , date);
    sprintf(cabecera + strlen(cabecera), "%s" , type);
    sprintf(cabecera + strlen(cabecera), "%s" , connect);
    sprintf(cabecera + strlen(cabecera), "%s" , length);

    /*Sirve al cliente el fichero Err400.html (Bad Request)*/
    if((send(connfd, cabecera, strlen(cabecera), 0)) < 0){
        syslog(LOG_ERR,"Error al enviar la cabecera al cliente.\n");
        return -1;
    }
    enviarRespuesta(connfd, "r", raiz);
    return 0;
}

/********
* FUNCION: int respuestaErr404(int connfd)
* ARGS_IN: int connfd - valor de la conexion con el cliente        
* DESCRIPCIÓN: Envia al cliente el codigo de respuesta 404 (Not Found)
* ARGS_OUT: int 0 - cabecera enviada con exito
*           int -1 - ha habido algun problema en el envio
********/
int respuestaErr404(int connfd){

    char *root;
    char serv_name[100], date[100], length[100];
    char connect[100], type[100], raiz[100];
    char respuesta[1200], cabecera[8000];
    FILE *fp = NULL;

    /*Guarda en raiz la ruta a Err404.html*/
    sprintf(raiz , "%s", obtenerPathFichero("/Errores/Err404.html"));

    /*Escribe la cabecera de respuesta con los valores:
            Server:
            Date:
            Content-type:
            Last-modified:
            Content-length:*/
    sprintf(serv_name, "Server: %s\r\n", obtenerNombreServidor());
    root = obtenerFechaActual();
    sprintf(date, "Date: %s\r\n", root);
    free(root);
    sprintf(connect, "Connection: Keep-Alive\r\n");
    sprintf(type, "Content-Type: text/html\r\n");
    
    /*Abre el fichero Err404.html*/
    fp = fopen(raiz, "r");
    if(fp == NULL){
        printf("Error al abrir el fichero %s\n", raiz);
        return -1;
    }
    fread(respuesta, 1199, 1, fp);
    fclose(fp);

    /*Escribe en la cabecera de la respuesta los elementos obtenidos antes*/
    sprintf(length, "Content-length: %d\r\n\r\n", (int)strlen(respuesta));

    sprintf(cabecera, "HTTP/1.1 404 Not Found\r\n");
    sprintf(cabecera + strlen(cabecera), "%s" , serv_name);
    sprintf(cabecera + strlen(cabecera), "%s" , date);
    sprintf(cabecera + strlen(cabecera), "%s" , type);
    sprintf(cabecera + strlen(cabecera), "%s" , connect);
    sprintf(cabecera + strlen(cabecera), "%s" , length);

    /*Sirve al cliente el fichero Err404.html (Not Found)*/
    if((send(connfd, cabecera, strlen(cabecera), 0)) < 0){
        syslog(LOG_ERR,"Error al enviar la cabecera al cliente.\n");
        return -1;
    }
    enviarRespuesta(connfd, "r", raiz);
    return 0;
}
