/*
* File:   daemonize.c
*
* Author: Jorge Gutierrez
*         Patricia Losana
*
* Description: codigo para demonizar un proceso y escribir mensajes log
*/


#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <signal.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <syslog.h>
#include "daemonize.h"

/**********
* FUNCION: void daemonize
* ARGS_IN: -
* DESCRIPCION: Funcion que genera un proceso demonio
* ARGS_OUT: -
**********/
void daemonize(){
	pid_t pid;

	pid = fork(); /*Fork al proceso padre*/

	/*ha ocurrido un error en el fork*/
	if (pid < 0) {
		exit(EXIT_FAILURE);
	}

	/*Si el fork ha ido bien, exit del proceso padre*/
	if (pid > 0) {
		exit (EXIT_SUCCESS);
	}

	if (setsid() < 0){ /*Crea un nuevo SID para el proceso hijo*/
		exit (EXIT_FAILURE);
	}


	/*Manejador de senyales necesario para terminar el demonio*/
	signal(SIGCHLD, SIG_IGN);
	signal(SIGHUP, SIG_IGN);

	/*Segundo fork para que el demonio no sea lider de sesion*/
	pid = fork();

	/*ha ocurrido un error en el fork*/
	if (pid < 0) {
		exit(EXIT_FAILURE);
	}

	/*Si el fork ha ido bien, exit del proceso padre*/
	if (pid > 0) {
		exit (EXIT_SUCCESS);
	}

	umask(0); /*establece nuevos permisos de fichero*/

	/*Cambia el directorio de trabajo a otro*/
	chdir("./");

	//syslog(LOG_INFO, "Cerrando los descriptores de fichero");
	int x; /*Varianle para recorrer los ficheros*/
	for (x = sysconf(_SC_OPEN_MAX); x >= 0; x--){
		close(x);
	}

	/*Abre el fichero log*/
	openlog("servidor_demonio", LOG_PID, LOG_DAEMON);
	return;
}
