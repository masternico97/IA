/* File:   server_library.h
*
* Author: Jorge Gutierrez
*         Patricia Losana
*
* Description: include de las funciones para server library
*/

#ifndef SERVER_LIBRARY_H
#define SERVER_LIBRARY_H

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <strings.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <sys/stat.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <unistd.h>
#include <pthread.h>
#include <assert.h>
#include <error.h>
#include <signal.h>
#include <time.h>
#include <errno.h>
#include <syslog.h>
#include <semaphore.h>



#define MAX_CONNECTIONS 20
#define TAM 20



int initiate_server(int prt_src);
int accept_request(int socketfd, struct sockaddr * cliaddr, socklen_t * clilen);
int process_request(int connfd);
int crearRespuestaGET(int connfd, char* ruta);
int crearRespuestaPOST(int connfd, char* ruta, char* args);
int crearRespuestaOPTIONS(int connfd);
char* respuestaScriptGET(char* ruta, char* raiz);
char* respuestaScriptPOST(char* raiz, char* buf);
int enviarCabecera(int connfd, char* serv_name, char* date,
                  		char* last, char* length, char* type);
int enviarRespuesta(int connfd, char* type, char* raiz);
char* obtenerPathFichero(char* ruta);
char* obtenerNombreServidor();
char* obtenerTypeFichero(char* raiz);
char* obtenerLastModiFichero(char* raiz);
char* obtenerFechaActual();
int respuestaErr400(int connfd);
int respuestaErr404(int connfd);


#endif
