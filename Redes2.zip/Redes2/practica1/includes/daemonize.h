/* File:   daemonize.h
*
* Author: Jorge Gutierrez
*         Patricia Losana
*
* Description: include de las funciones para daemonize
*/

#ifndef DAEMONIZE_H
#define DAEMONIZE_H


void daemonize();

#endif
