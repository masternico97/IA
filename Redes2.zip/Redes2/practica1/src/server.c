/*
* File:   server.c
*
* Author: Jorge Gutierrez
*         Patricia Losana
*
* Description: codigo para un servidor demonio concurrente
*/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <strings.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <unistd.h>
#include <pthread.h>
#include <netdb.h>
#include <signal.h>
#include <sys/stat.h>
#include <syslog.h>

#include "server_library.h"
#include "daemonize.h"


int connfd = 0;
sem_t sem;

static void *justDoIt(void *arg);

void manejador_SIGINT (int sennal);

int main(int argc, char *argv[]){

    int socketfd, max_clients, listen_port; 
    socklen_t clilen;
    struct sockaddr_in cliaddr;
    pthread_t hilo;
    void manejador_SIGTERM ();
    char* root;
    char aux[100];
    FILE *fp = NULL;

    /*Funcion para demonizar el servidor (se puede comprobar por terminal 
    con ps -ef | grep ./server*/
    daemonize();

    /*Manipulacion de la señal Ctrl+C*/
    if (signal (SIGINT, manejador_SIGINT) == SIG_ERR) {
        printf("Error al configurar la señal SIGTERM\n");
        return -1;
    }

    /*Abrimos el fichero server.conf para guardar el numero de clientes y 
    puerto usado*/
    fp = fopen("server.conf", "r");
    if(fp == NULL){
    	printf("Error al abrir el fichero de server.conf\n");
    	return -1;
    }
    
    /*Recorremos la primera linea de server.conf (#Fichero de ...)*/
    fgets(aux, 100, fp);
    
    /*Recorremos la segunda linea de server.conf sobreescribiendo la lectura 
    anterior (server_root: htmlfiles ...)*/
    fgets(aux, 100, fp);
    
    /*Recorremos la tercera linea de server.conf sobreescribiendo la lectura 
    anterior (max_clients ...)*/
    fgets(aux, 100, fp);

    /*Parseamos la linea max_clients rompiendo la cadena en los espacios*/
    root = strtok(aux, " \n"); /*root es 'max_clients = 10'*/
    root = strtok(NULL, " \n"); /*root es '= 10' */
    root = strtok(NULL, " \n"); /*root es '10' */

    /*Maximo de clientes atendidos (conversion de string a integer)*/
    max_clients = atoi(root);

    /*Limpiamos la variable aux para seguir recorriendo server.conf*/
    bzero(aux, 100);

    /*Recorremos la segunda linea de server.conf sobreescribiendo la lectura 
    anterior (server_root: listen_port ...)*/
    fgets(aux, 100, fp);

    /*Parseamos la linea listen_port rompiendo la cadena en los espacios*/
    root = strtok(aux, " \n"); /*root es 'listen_port = 8000' */
    root = strtok(NULL, " \n"); /*root es '= 8000' */
    root = strtok(NULL, " \n"); /*root es '8000' */

    /*Puerto en el que escuchamos (conversion de string a integer)*/
    listen_port = atoi(root);

    /*Devolvemos el puntero de lector del fichero a la posicion inicial*/
    rewind(fp);

    /*Cerramos el fichero*/
    fclose(fp);


    /*Inicializacion del servidor con initiate_server (llamadas a socket(), 
    bind() y listen() dentro de la misma)*/
    if ((socketfd = initiate_server(listen_port)) < 0){
        printf("Error en la inicializacion del servidor\n");
        return -1;
    }

    /*Limpiamos la parte de memoria que va a contener la direccion de cliente*/
    bzero((char *) &cliaddr, sizeof(cliaddr));

    /*Iniciamos el semaforo que va a tener el control*/
    sem_init(&sem, 0, max_clients);

    while(1) {
        /*El servidor se queda en la llamada accept dentro de la funcion accept_request()*/
        connfd = accept_request(socketfd, (struct sockaddr *) &cliaddr, &clilen);
        if(connfd == -1){
        	printf("Error al aceptar la conexion\n");
        	sem_destroy(&sem);
        	return -1;
        }

        /*si todos los hilos estan ocupados, se quedara esperando aqui*/
        sem_wait(&sem);

        /*Si al menos hay un hilo disponible, creara un hilo para atender la respuesta
        y llama a la funcion justDoIt*/
        pthread_create (&hilo, NULL , &justDoIt , (void *) connfd);

        /*Incrementa en 1 el valor del semaforo*/
        sem_post(&sem);

    }
    /*Cierra el log abierto en la funcion daemonize*/
    closelog();
    return 0;

}


/**********
* FUNCION: void *justDoIt(void *arg)
* ARGS_IN: void *arg - argumento sobre el que va a procesar la peticion
* DESCRIPCION: Funcion que recibe la peticion del cliente y la procesa
* ARGS_OUT: void *- 
**********/
static void *justDoIt(void *arg){

    int res = 0;
    /*Cuando termine de ejecutar lo que necesita, cerrara el hilo*/
    pthread_detach(pthread_self());

    do{
        /*Llamada a process request dentro de server_library (recv la peticion
        y la parsea)*/
        res = process_request((int) arg);
    }while(res == 0);
    closelog();
    return 0;
}

/**********
* FUNCION: manejador_SIGINT (int sennal)
* ARGS_IN: int sennal - valor de la sennal que entra
* DESCRIPCION: manejador de la sennal Ctrl + C (evita que termine de 
*              forma abrupta al recibir la sennal)
* ARGS_OUT: void - no devuelve argumentos
**********/
void manejador_SIGINT (int sennal) {
    shutdown(connfd, SHUT_RDWR);
    close(connfd);
    sem_destroy(&sem);
    printf("\nConexion cerrada por Ctr+C\n");
    signal(SIGINT, SIG_DFL);

    return;
}
